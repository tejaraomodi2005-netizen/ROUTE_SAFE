import 'package:flutter/material.dart';

import '../../shared/widgets/app_card.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Flutter Starter')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          AppCard(
            title: 'Your app starts here',
            subtitle: 'Add features inside lib/features/ and reusable UI inside lib/shared/widgets/.',
            icon: Icons.rocket_launch_outlined,
          ),
          SizedBox(height: 16),
          AppCard(
            title: 'Lightweight by default',
            subtitle: 'This starter uses only Flutter SDK dependencies.',
            icon: Icons.speed,
          ),
        ],
      ),
    );
  }
}
