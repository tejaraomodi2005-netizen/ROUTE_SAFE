# Flutter Fast Starter

A lightweight Flutter starter template with a clean folder structure and a simple Material 3 app.

## Requirements
- Flutter SDK (stable)
- Android Studio
- Android SDK + Android Emulator, or an Android phone with USB debugging

## Setup (Windows)
1. Install Flutter SDK from https://docs.flutter.dev/get-started/install/windows/mobile
2. Add `<flutter-sdk>\\bin` to your Windows PATH.
3. Open PowerShell and run:
   ```powershell
   flutter doctor
   ```
4. In Android Studio, install the Flutter and Dart plugins:
   - File → Settings → Plugins → Marketplace
   - Install **Flutter** (Dart is installed as a dependency)
   - Restart Android Studio
5. Install Android SDK tools:
   - File → Settings → Languages & Frameworks → Android SDK
   - Install a recent Android SDK Platform, Android SDK Build-Tools, and Android Emulator
6. Create an emulator:
   - Tools → Device Manager → Create Device
   - Choose a phone → choose a system image → Finish → Start
7. Extract this ZIP, open the extracted folder in Android Studio.
8. In the project terminal, run:
   ```powershell
   flutter create .
   flutter pub get
   flutter run
   ```

`flutter create .` generates the Android and other platform folders for this project. If prompted about overwriting files, do not overwrite your existing `lib/main.dart`.

## Project structure
```text
lib/
  main.dart
  app.dart
  core/
    theme/
      app_theme.dart
  features/
    home/
      home_page.dart
  shared/
    widgets/
      app_card.dart
assets/
  images/
  icons/
test/
  widget_test.dart
```

## Performance notes
- Keep dependencies minimal.
- Use `const` widgets where possible.
- Use `ListView.builder` for long lists.
- Avoid expensive work in `build()`.
- Profile release builds with `flutter run --profile`.
