import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_fast_starter/app.dart';

void main() {
  testWidgets('starter home page renders', (tester) async {
    await tester.pumpWidget(const StarterApp());
    expect(find.text('Flutter Starter'), findsOneWidget);
    expect(find.text('Your app starts here'), findsOneWidget);
  });
}
